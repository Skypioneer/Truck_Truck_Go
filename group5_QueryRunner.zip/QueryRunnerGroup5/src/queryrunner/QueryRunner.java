/**
 * PROJECT TEAM 5 MILESTONE 3 TRUCK TRUCK GO
 *
 *  Features:
 *  GUI:
 *  - New Three Tone Color Scheme!
 *  - Automatically populated connection info!
 *  - Query Descriptions in selection pane!
 *  - Resize Query Dropdown and Components moved!
 *
 *  CONSOLE:
 *  - "Perfectly" Formatted Tables
 *      - Exact column widths
 *      - Table-like separator lines
 *  - Automatic connection to our group project
 *  - Handles parameters, action queries, like parameters
 *  - Query Menu with Descriptions
 *  - Try, catch, stack trace and print of every connection/query error.
 *
 *  QUERIES:
 *  - "Like" parameter used for truck search in Query 12
 *  - Update in Query 11
 *  - Insert with subqueries in Query 13
 *  - Dates and CURDATE in Query 5
 *  - Parameters in Queries 9, 11, 12 13
 *  - and MORE!
 */
package queryrunner;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class 
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {

    
    public QueryRunner()
    {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error="";
    
        

        
        this.m_projectTeamApplication="Truck Truck Go";
        
        // Each row that is added to m_queryArray is a separate query. It does not work on Stored procedure calls.
        // The 'new' Java keyword is a way of initializing the data that will be added to QueryArray. Please do not change
        // Format for each row of m_queryArray is: (QueryText, ParamaterLabelArray[], LikeParameterArray[], IsItActionQuery, IsItParameterQuery)

        //    QueryText is a String that represents your query. It can be anything but Stored Procedure
        //    Parameter Label Array  (e.g. Put in null if there is no Parameters in your query, otherwise put in the Parameter Names)
        //    LikeParameter Array  is an array I regret having to add, but it is necessary to tell QueryRunner which parameter has a LIKE Clause. If you have no parameters, put in null. Otherwise put in false for parameters that don't use 'like' and true for ones that do.
        //    IsItActionQuery (e.g. Mark it true if it is, otherwise false)
        //    IsItParameterQuery (e.g.Mark it true if it is, otherwise false)
        
        m_queryArray.add(new QueryData("SELECT food_name AS Food, nutr_fat_g AS Fat\n" +
                "FROM food f JOIN nutrition n ON f.nutr_id = n.nutr_id\n" +
                "WHERE nutr_fat_g < (nutr_fat_g + nutr_protein_g + nutr_carbohydrates_g) * .2\n" +
                "ORDER BY Fat;", null, null, false, false));

        m_queryArray.add(new QueryData("SELECT nutr_calories AS Cal, bev_name AS Beverage\n" +
                "FROM beverage b JOIN nutrition n on b.nutr_id = n.nutr_id\n" +
                "WHERE nutr_calories < 200\n" +
                "ORDER by Cal;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT ROUND(AVG(rating_rating), 2) as Rating, vend_name as Vendor\n" +
                "FROM vendor v JOIN orders o ON v.vend_id = o.vend_id\n" +
                "JOIN rating r ON r.rating_id = o.rating_id\n" +
                "GROUP BY v.vend_id\n" +
                "HAVING Rating >= 3\n" +
                "ORDER BY Rating desc;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT contact_fName as First, contact_lName as Last, count(rating_id) as NumRatings\n" +
                "FROM contact_information ci JOIN customer c ON ci.contact_id = c.contact_id\n" +
                "JOIN rating r on c.cust_id = r.cust_id\n" +
                "GROUP BY c.cust_id\n" +
                "HAVING NumRatings > 2\n" +
                "ORDER BY NumRatings desc;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT vend_name as Vendor\n" +
                "FROM vendor v JOIN schedule s on v.vend_id = s.vend_id\n" +
                "JOIN week w on w.week_id = s.week_id\n" +
                "JOIN time t on t.time_id = s.time_id\n" +
                "WHERE w.week_day = DAYNAME(CURDATE())\n" +
                "AND t.time_openTime < TIME(CURTIME())\n" +
                "AND t.time_closeTime > TIME(CURTIME());\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT v.vend_name as Vendor, ROUND(AVG(f.food_menu_price),2) AS AvgPrice\n" +
                "FROM food_menu f JOIN vendor v USING (vend_id)\n" +
                "GROUP BY vend_id\n" +
                "ORDER BY AvgPrice ASC;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT vend_name as Vendor, contact_enrollDate as Enrolled\n" +
                "FROM vendor v JOIN contact_information ci ON v.contact_id = ci.contact_id\n" +
                "WHERE contact_enrollDate  > CURDATE() - 365\n" +
                "ORDER BY Enrolled;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT loc_city as City, count(vend_id) as NumTrucks\n" +
                "FROM location l JOIN schedule s on l.loc_id = s.loc_id\n" +
                "GROUP BY City\n" +
                "ORDER BY NumTrucks desc;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT food_name AS FoodName, nutr_calories as Cal, nutr_fat_g as Fat, nutr_carbohydrates_g as Carb, nutr_protein_g as Prot\n" +
                "FROM vendor v JOIN food_menu fm ON v.vend_id = fm.vend_id\n" +
                "JOIN food f ON f.food_id = fm.food_id\n" +
                "JOIN nutrition n on f.nutr_id = n.nutr_id\n" +
                "WHERE vend_name = ?;\n", new String [] {"TRUCK_NAME"}, new boolean [] {false}, false, true));
        m_queryArray.add(new QueryData("SELECT c.contact_enrollDate AS EnrollDate , COUNT(r.rating_rating) as NumGoodRatings\n" +
                "FROM contact_information c\n" +
                "JOIN customer cu ON cu.contact_id = c.contact_id\n" +
                "LEFT JOIN rating r ON cu.cust_id = r.cust_id\n" +
                "WHERE r.rating_rating IN (SELECT rating_rating FROM rating WHERE rating_rating >= 4)\n" +
                "GROUP BY EnrollDate\n" +
                "ORDER BY EnrollDate ASC;\n", null, null,  false, true));
        m_queryArray.add(new QueryData("SELECT vend_name AS TruckName from vendor\n" +
                "WHERE vend_name like ?", new String [] {"VEND_NAME (Like)"}, new boolean [] {true}, false, true));
        m_queryArray.add(new QueryData("UPDATE vendor SET vend_name = ?\n" +
                "WHERE vend_name = ?",new String [] {"new VEND_NAME", "old VEND_NAME"}, new boolean [] {false, false}, true, true));
        m_queryArray.add(new QueryData("INSERT INTO food_menu (vend_id, food_id, food_menu_price)\n" +
                "SELECT vend_id, food_id, ?\n" +
                "FROM vendor, food\n" +
                "WHERE vend_name = ? AND food_name = ?",new String [] {"FOOD_MENU_PRICE", "VEND_NAME", "FOOD_NAME", }, new boolean [] {false, false, false}, true, true));
                       
    }

    public static String GetQueryDesc(int queryNum)
    {
        //Returns query description for console and gui apps
        //No breaks needed because every case returns
        switch (queryNum) {
            case 1:
                return "Low fat foods";
            case 2:
                return "Low carb beverages";
            case 3:
                return "Highly Rated Food Trucks";
            case 4:
                return "Customers with >2 Ratings";
            case 5:
                return "Trucks open RIGHT NOW";
            case 6:
                return "Most Expensive Trucks";
            case 7:
                return "Newest Trucks";
            case 8:
                return "Number of trucks by city";
            case 9:
                return "Food menu of a given truck";
            case 10:
                return "Number of good ratings by customer enrollment date";
            case 11:
                return "Search for a truck by name.(Like)";
            case 12:
                return "Update a truck's name.";
            case 13:
                return "Add an existing food item to a truck's menu.";
            default:
                return "No information for this query yet.";
        }
    }
    public int GetTotalQueries()
    {
        return m_queryArray.size();
    }
    
    public int GetParameterAmtForQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }
              
    public String  GetParamText(int queryChoice, int parmnum )
    {
       QueryData e=m_queryArray.get(queryChoice);        
       return e.GetParamText(parmnum); 
    }   

    public String GetQueryText(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetQueryString();        
    }
    
    /**
     * Function will return how many rows were updated as a result
     * of the update query
     * @return Returns how many rows were updated
     */
    
    public int GetUpdateAmount()
    {
        return m_updateAmount;
    }
    
    /**
     * Function will return ALL of the Column Headers from the query
     * @return Returns array of column headers
     */
    public String [] GetQueryHeaders()
    {
        return m_jdbcData.GetHeaders();
    }
    
    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     * @return multi-dimensional array of String data based on the resultset 
     * from the query
     */
    public String[][] GetQueryData()
    {
        return m_jdbcData.GetData();
    }

    public String GetProjectTeamApplication()
    {
        return m_projectTeamApplication;        
    }
    public boolean  isActionQuery (int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }
    
    public boolean isParameterQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryParm();
    }
    
     
    public boolean ExecuteQuery(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
        return bOK;
    }
    
     public boolean ExecuteUpdate(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }   
    
      
    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase)
    {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (bConnect == false)
            m_error = m_jdbcData.GetError();        
        return bConnect;
    }
    
    public boolean Disconnect()
    {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return true;
    }
    
    public String GetError()
    {
        return m_error;
    }

    public static String getModeResponse(Scanner kb)
    {
        String ret = "";
        while (!ret.equals("C") && !ret.equals("G")) {
            System.out.print("\nEnter c for Console or g for Graphical Interface: ");
            ret = kb.nextLine();
            ret = ret.toUpperCase();
        }
        return ret;
    }

    public static void printMenu(int size) {

        //Simply prints the full menu of Query Options!
        System.out.println("Query options:");
        for (int i = 1; i <= size; i++){

            System.out.println( i + ": " + GetQueryDesc(i));
        }
        System.out.println();

    }

    public static String[] getParms(int q, QueryRunner queryrunner,
                                    Scanner kb) {
        //Collect all parameters from user and return as array of strings
        int parmNums = 0;
        String[] ret = {};

        //return empty array if no parameters are needed
        if (!queryrunner.isParameterQuery(q)) {
            return ret;
        }

        //Otherwise prompt the user for each parameter and add to array
        parmNums = queryrunner.GetParameterAmtForQuery(q);
        ret = new String[parmNums];
        for (int i = 0; i < parmNums; i++) {
            System.out.print("Enter value for "
                              + queryrunner.GetParamText(q,i) + ": ");
            ret[i] = kb.nextLine();
            System.out.println();
        }

        //return array
        return ret;

    }

    public static void executeQuery(int q, QueryRunner queryrunner,
                                    Scanner kb) {

        String[] parms;

        // if invalid query is selected, print error and don't execute query
        if (q < 0) {
            System.out.println("Error: Invalid Query Number!\n");
            return;
        }

        //Print out SQL command of query to execute
        System.out.println(queryrunner.GetQueryText(q) + "\n");

        parms = getParms(q, queryrunner, kb);

        //If action query, just display rows affected
        if (queryrunner.isActionQuery(q)) {
            try {
                if (queryrunner.ExecuteUpdate(q, parms)) {
                    System.out.println("Rows affected = "
                            + queryrunner.GetUpdateAmount());
                    System.out.println();
                } else {
                    System.out.println("Query could not be executed!");
                }
            } catch (Exception e) {
                // prints lines + call stack
                e.printStackTrace();

                // Prints exception
                System.out.println(e);
            }
        } else{
            //If non-action query, display data
            try {
                if (queryrunner.ExecuteQuery(q, parms)) {
                    printQueries(queryrunner);
                } else {
                    System.out.println("Query could not be executed!");
                }
            } catch (Exception e) {
                // prints lines + call stack
                e.printStackTrace();

                // Prints exception
                System.out.println(e);
            }
        }
    }

    public static void printQueries(QueryRunner queryrunner) {

        //Print results of query after successful execution
        String[] queryHeaders = {};
        String[][] queryResults;
        int[] columnLengths;
        queryResults = queryrunner.GetQueryData();   //results of query
        queryHeaders = queryrunner.GetQueryHeaders();//query headers
        columnLengths = new int[queryHeaders.length];//lengths of columns
                                                     // for formatting


        //find longest string in each column
        for (int i = 0; i < queryHeaders.length && i < 10; i++) {
            columnLengths[i] = queryHeaders[i].length();
        }

        for (int i = 0; i < queryResults.length; i++) {
            for (int j = 0; j < queryResults[i].length; j++) {
                columnLengths[j] = Math.max(columnLengths[j],
                        queryResults[i][j].length());
            }
        }

        // Nicely print Headers
        for (int i = 0; i < queryHeaders.length; i++) {
            if (i > 0) {
                System.out.print("|");
            }
            System.out.printf("%-"+columnLengths[i] +
                    "s",queryHeaders[i]);
        }
        System.out.println();
        // Seperate headers and data
        for (int i = 0; i < queryHeaders.length; i++) {
            if (i > 0) {
                System.out.print("-");
            }
            System.out.print(String.format("%-"+columnLengths[i] +
                    "s","").replace(' ', '-'));
        }
        System.out.println();
        // Nicely print data
        for (int i = 0; i < queryResults.length; i++) {
            for (int j = 0; j < queryResults[i].length; j++) {
                if (j > 0) {
                    System.out.print("|");
                }
                System.out.printf("%-"+columnLengths[j] +
                        "s",queryResults[i][j]);
            }
            System.out.println();
        }
        System.out.println();
    }

    public static void Connect(QueryRunner queryrunner) {
        //Connects and throws errors with any issues
        System.out.println("Connecting you to the default Server.\n");
        try {
            if (queryrunner.Connect("cs100.seattleu.edu",
                    "mm_cpsc502101team05",
                    "mm_cpsc502101team05Pass-",
                    "mm_cpsc502101team05")) {
                System.out.println("Connection Successful!\n");
            } else {
                System.out.println("ConnectionFailed!\n");
            }
        } catch (Exception e) {
            // prints lines + call stack
            e.printStackTrace();

            // Prints exception
            System.out.println(e);
        }
    }

    public static void Disconnect(QueryRunner queryrunner) {
        //Disconnects and throws errors
        try {
            if (queryrunner.Disconnect()) {
                System.out.println("Disconnect Successful!\n");
            } else {
                System.out.println("Disconnect Failed!\n");
            }
        } catch (Exception e) {
            // prints lines + call stack
            e.printStackTrace();

            // Prints exception
            System.out.println(e);
        }
    }
 
    private QueryJDBC m_jdbcData;
    private String m_error;    
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;  
    private int m_updateAmount;
            
    /**
     * @param args the command line arguments
     */
    

    
    public static void main(String[] args) {

        //instance of QR to do all the work!
        final QueryRunner queryrunner = new QueryRunner();
        Scanner keyboard = new Scanner(System.in); // Scanner to get input
        int queryNum = 0;   //holds selected query
        String response = getModeResponse(keyboard); // User's mode selection

        // If GUI selected, start GUI
        if (response.equals("G")) {

            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {

                    new QueryFrame(queryrunner).setVisible(true);
                }            
            });

        //Else console program
        } else {

            System.out.println("\nWelcome to the Truck Truck Go console query System!\n");
            //Automatic connection! spiffy!
            Connect(queryrunner);

            // While a valid query is selected
            while (queryNum >= 0) {

                // Nicely print menu of queries
                printMenu(queryrunner.GetTotalQueries());

                // Collect user's desired query
                System.out.print("Enter Query Number: ");
                queryNum = keyboard.nextInt()-1;
                keyboard.nextLine();
                System.out.println();
                // Execute user's query
                executeQuery(queryNum, queryrunner, keyboard);

                // Wait for user to continue or exit
                System.out.print("Hit Enter to Continue or type 'Exit' " +
                        "to quit: ");
                if (keyboard.nextLine().toLowerCase().equals("exit")) {
                    queryNum = -1;
                } else {
                    queryNum = 0;
                }
                System.out.println();
            }
            System.out.println("Thank you for using the Truck Runner" +
                               " console application.\n");
            // Disconnect
            Disconnect(queryrunner);
        }
 
    }    
}
